document.getElementById("addAffiliateForm").addEventListener("submit", function(event) {
    event.preventDefault();
    addAffiliate();
});

function addAffiliate() {
    let affiliates = JSON.parse(localStorage.getItem("affiliates")) || [];
    let newAffiliate = {
        name: document.getElementById("name").value,
        phone: document.getElementById("phone").value,
        subscription: document.getElementById("subscription").value,
        shares: document.getElementById("shares").value,
        totalDebt: document.getElementById("totalDebt").value,
        payments: document.getElementById("payments").value,
        lastPaymentDate: document.getElementById("lastPaymentDate").value,
        remainingDebt: document.getElementById("remainingDebt").value
    };

    affiliates.push(newAffiliate);
    localStorage.setItem("affiliates", JSON.stringify(affiliates));
    displayAffiliates();
}

function displayAffiliates() {
    let affiliates = JSON.parse(localStorage.getItem("affiliates")) || [];
    let tableBody = document.getElementById("affiliateList");
    tableBody.innerHTML = "";

    affiliates.forEach((affiliate, index) => {
        let row = `<tr>
            <td>${affiliate.name}</td>
            <td>${affiliate.phone}</td>
            <td>${affiliate.subscription}</td>
            <td>${affiliate.shares}</td>
            <td>${affiliate.totalDebt}</td>
            <td>${affiliate.payments}</td>
            <td>${affiliate.lastPaymentDate}</td>
            <td>${affiliate.remainingDebt}</td>
            <td><button onclick="showDetails(${index})">عرض</button></td>
            <td><button onclick="editAffiliate(${index})">تعديل</button></td>
            <td><button onclick="deleteAffiliate(${index})" style="background: red;">حذف</button></td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}

function showDetails(index) {
    let affiliates = JSON.parse(localStorage.getItem("affiliates"));
    let affiliate = affiliates[index];
    document.getElementById("detailsContent").innerHTML = `
        <p>الاسم: ${affiliate.name}</p>
        <p>رقم الهاتف: ${affiliate.phone}</p>
        <p>الاشتراك: ${affiliate.subscription}</p>
        <p>الأسهم: ${affiliate.shares}</p>
        <p>إجمالي الديون: ${affiliate.totalDebt}</p>
        <p>الدفعات: ${affiliate.payments}</p>
        <p>تاريخ آخر دفعة: ${affiliate.lastPaymentDate}</p>
        <p>الدين المتبقي: ${affiliate.remainingDebt}</p>
    `;
    document.getElementById("detailsModal").style.display = "block";
}

function closeDetailsModal() {
    document.getElementById("detailsModal").style.display = "none";
}

function deleteAffiliate(index) {
    let affiliates = JSON.parse(localStorage.getItem("affiliates"));
    affiliates.splice(index, 1);
    localStorage.setItem("affiliates", JSON.stringify(affiliates));
    displayAffiliates();
}

displayAffiliates();
function showDetails(index) {
    let affiliates = JSON.parse(localStorage.getItem("affiliates"));
    let affiliate = affiliates[index];

    document.getElementById("detailsContent").innerHTML = `
        <h2 style="color:#007bff;">تفاصيل المنتسب</h2>
        <p><strong>الاسم:</strong> ${affiliate.name}</p>
        <p><strong>رقم الهاتف:</strong> ${affiliate.phone}</p>
        <p><strong>الاشتراك الشهري:</strong> ${affiliate.subscription}</p>
        <p><strong>الأسهم:</strong> ${affiliate.shares}</p>
        <p><strong>إجمالي الديون:</strong> ${affiliate.totalDebt}</p>
        <p><strong>الدفعات:</strong> ${affiliate.payments}</p>
        <p><strong>تاريخ آخر دفعة:</strong> ${affiliate.lastPaymentDate}</p>
        <p><strong>الدين المتبقي:</strong> ${affiliate.remainingDebt}</p>
    `;
    
    document.getElementById("detailsModal").style.display = "block";
}